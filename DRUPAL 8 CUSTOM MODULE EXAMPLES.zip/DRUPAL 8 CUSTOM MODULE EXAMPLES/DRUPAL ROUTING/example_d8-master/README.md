Routing Example in Drupal 8
==========

Symfony2 an OO application framework, will be part of Core.
Router lets you define creative URLs that you map to different areas of your application.

This module shows you the basic example how to create routing and the new .info (dot info file) to info.yml (YAML).