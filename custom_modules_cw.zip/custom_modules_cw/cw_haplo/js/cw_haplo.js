(function ($) {
  Drupal.behaviors.cwHaploAccessData = {
    attach: function (context, settings) {
		var data_cw_types_count = settings.cw_types_array;
		//alert(data_cw_types_count);
		//console.log(data_cw_types_count);
		var data_cw_count = Drupal.settings.cw_haplo.cw_types_array;
		//console.log(data_cw_count.Annual);
    }
  };
})(jQuery);
