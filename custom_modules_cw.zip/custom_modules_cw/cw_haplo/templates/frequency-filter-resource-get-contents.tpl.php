<?php 
//print_r($results);
$img_src = array();
$img_src = array('E-Book' => 'Resource.jpg','Document'=> 'Document.png','compliance_in_depth_reports' => 'In-Depth-Report.jpg','Slides' => 'Slides.jpg');
?>
<div class="filter-contents-haplo">
	<div class="gk">
		<div class="go"></div>
		<?php 
		foreach ($results as $key=>$value) {?>
		<div class="gl">
			<span class="be hu">
				<span class="hx"></span>
				<?php
				if (array_key_exists($key,$img_src)) { ?>
				<span class="ij ib"><img src="/<?php echo drupal_get_path('module', 'cw_haplo')?>/images/<?php print $img_src[$key] ;?>" /></span>
				<?php } ?>
			</span>
			<a href="/search-resources-reports?field_topic_tid=&combine=<?php print $key;?>">
			<?php if($key == 'compliance_in_depth_reports'){ $key = 'In-Depth Report'; } else{ $key = $key; } ?>
			<?php print $key ;?></a> 
			<span class="gm"><?php print $value ;?></span>
		</div>
		<?php }
		?>
		<div class="go"></div>
	</div>
</div>
