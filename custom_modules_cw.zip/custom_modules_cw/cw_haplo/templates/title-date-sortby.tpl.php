<?php
	  $current_path = request_uri(); 
	  $sort_path_split = explode('sort_by',$current_path);
	  $params_url = drupal_get_query_parameters();
	  $sort_by_title = (empty($params_url))? $sort_path_split[0].'?sort_by=title&sort_order=ASC' : $sort_path_split[0].'&sort_by=title&sort_order=ASC';
	  $sort_by_date = (empty($params_url))? $sort_path_split[0].'?sort_by=created&sort_order=DESC' : $sort_path_split[0].'&sort_by=created&sort_order=DESC';
?>
<div class="order-by-hap">Ordered by 
	<a class="order-title" href="<?php print $sort_by_title; ?>">Title</a> or <a class="order-date" href="<?php print $sort_by_date; ?>">Date</a>
</div>