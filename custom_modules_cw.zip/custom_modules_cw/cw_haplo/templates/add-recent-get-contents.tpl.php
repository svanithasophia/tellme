<?php
?>

<div class="add-recent-content-block">
<div class="add-haplo-block"><a href="/add/content/haplo">Add</a></div>
<div class="recent-haplo-block"><a href="/recently-add-edit-content">Recent</a></div>
</div>