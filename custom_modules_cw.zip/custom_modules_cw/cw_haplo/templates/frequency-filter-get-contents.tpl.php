<?php 
//print_r($results);
?>
<div class="filter-contents-haplo">
	<div class="gk">
		<div class="go"></div>
		<?php 
		foreach ($results as $key=>$value) {?>
		<div class="gl">
			<span class="be hu">
				<span class="hx"></span>
				<span class="ij ib"><img src="/<?php echo drupal_get_path('module', 'cw_haplo')?>/images/<?php print $key ;?>.jpg" /></span>
			</span>
			<a href="/search-events?combine=<?php print $key ;?>&field_topic_tid=All&sort_by=title&sort_order=ASC"><?php print $key ;?></a> 
			<span class="gm"><?php print $value ;?></span>
		</div>
		<?php }
		?>
		<?php /*
		<div class="gl">
			<span class="be hu">
				<span class="hx"></span>
				<span class="ij ib"></span>
			</span>
			<a href="/search-events?combine=Annual&field_topic_tid=All&sort_by=title&sort_order=ASC">Annual</a> 
			<span class="gm"><?php print $results['Annual'] ;?></span>
		</div>
		<div class="gl">
			<span class="be hu">
				<span class="hx"></span>
				<span class="ig ib"></span>
			</span>
			<a href="/search-events?combine=West&field_topic_tid=All&sort_by=title&sort_order=ASC">West</a> 
			<span class="gm"><?php print $results['West'] ;?></span>
		</div>
		<div class="gl">
			<span class="be hu">
				<span class="hx"></span>
				<span class="ii ib"></span>
			</span>
			<a href="/search-events?combine=Europe&field_topic_tid=All&sort_by=title&sort_order=ASC">Europe</a> 
			<span class="gm"><?php print $results['Europe'] ;?></span>
		</div>
		<div class="gl">
			<span class="be hu">
				<span class="hx"></span>
				<span class="ij ib"></span>
			</span>
			<a href="/search-events?combine=xxx&field_topic_tid=All&sort_by=title&sort_order=ASC">xxx</a> 
			<span class="gm"><?php print $results['xxx'] ;?></span>
		</div>*/?>
		<div class="go"></div>
	</div>
</div>
