(function ($) {
  $(document).ready(function() {
    $(".region-nav").naver({
      animated: true,
      label: false
    });
    $.scrollUp({
        scrollText: ''// Text for element
      });
  });
})(jQuery);
