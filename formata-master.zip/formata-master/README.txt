Drupal 8 theme (Update for D8 Beta2).

Simple, clean, minimal configurations theme.


• Drupal's 8 TWIG based (obviously)
• SASS partials structure.
• Singularity Grid System for responsive grids. (No longer used, but can be added trough the Gem file if needed)
• Breakpoint media queries in Sass
• Typecsset for vertical rhythm typography
• Code syntax highlighting with Rainbow
• Google Fonts Merriweather Serif and Sans-serif families
• Font Awesome Icons
